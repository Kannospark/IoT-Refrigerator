# Hi3861鸿蒙版本微信小程序

#### 介绍
微信小程序连接腾讯云部分参考了腾讯github智慧农业的开源项目：https://github.com/OpenAtomFoundation/TencentOS-tiny/tree/master
适用于OpenHarmony 开源项目的Hi3861V100硬件、软件
基于UDP协议实现微信小程序、Hi3861V100板端的局域网交互
基于MQTT协议实现微信小程序云端、Hi3861V100板端的交互

#### 软件架构
软件架构说明


#### 安装教程

1.  微信小程序官网下载开发工具：https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html
2.  选择合适的版本下载后安装即可

#### 使用说明

1.  本仓库的小程序代码开发环境使用的是windows 10 64位的开发环境
2.  使用微信小程序云开发

#### 参与贡献

1.  Fork 本仓库
2.  提交代码
3.  新建 Pull Request


#### 特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
