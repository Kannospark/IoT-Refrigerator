# Hi3861鸿蒙版本微信小程序

#### Description
微信小程序连接腾讯云部分参考了腾讯git智慧农业的开源项目：https://github.com/OpenAtomFoundation/TencentOS-tiny/tree/master
适用于OpenHarmony 开源项目的Hi3861V100硬件、软件
基于UDP协议实现微信小程序、Hi3861V100板端的局域网交互
基于MQTT协议实现微信小程序云端、Hi3861V100板端的交互

#### Software Architecture
Software architecture description

#### Installation

1.  xxxx
2.  xxxx
3.  xxxx

#### Instructions

1.  xxxx
2.  xxxx
3.  xxxx

#### Contribution

1.  Fork the repository
2.  Create Feat_xxx branch
3.  Commit your code
4.  Create Pull Request


#### Gitee Feature

1.  You can use Readme\_XXX.md to support different languages, such as Readme\_en.md, Readme\_zh.md
2.  Gitee blog [blog.gitee.com](https://blog.gitee.com)
3.  Explore open source project [https://gitee.com/explore](https://gitee.com/explore)
4.  The most valuable open source project [GVP](https://gitee.com/gvp)
5.  The manual of Gitee [https://gitee.com/help](https://gitee.com/help)
6.  The most popular members  [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
